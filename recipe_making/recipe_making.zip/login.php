<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Include the database connection file
include 'config.php';

$RequestMethod = $_SERVER["REQUEST_METHOD"];

if ($RequestMethod == "POST") {
    try {
        // Get the POST data
        $input = json_decode(file_get_contents('php://input'), true);

        // Extract user details from the request
        $username = $input['username'] ?? '';
        $profile_image = $input['profile_image'] ?? '';
        $followers = isset($input['followers']) ? (int)$input['followers'] : 0;
        $following = isset($input['following']) ? (int)$input['following'] : 0;
        $posts = isset($input['posts']) ? (int)$input['posts'] : 0;

        // Validate inputs
        if (empty($username) || empty($profile_image)) {
            throw new Exception("Username and profile_image are required");
        }

        // Insert or update user details in the database
        // Check if the user already exists in the 'users' table (adjust table name and fields as needed)
        $sql = "SELECT user_id FROM users WHERE username = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // If user exists, update the user details
            $user = $result->fetch_assoc();
            $user_id = $user['user_id'];

            $updateSql = "UPDATE users SET profile_image = ?, followers = ?, following = ?, posts = ? WHERE user_id = ?";
            $updateStmt = $conn->prepare($updateSql);
            $updateStmt->bind_param("siiii", $profile_image, $followers, $following, $posts, $user_id);
            $updateStmt->execute();

            if ($updateStmt->affected_rows > 0) {
                $response = array(
                    'status' => true,
                    'message' => 'User details updated successfully',
                    'data' => array(
                        'username' => $username,
                        'profile_image' => $profile_image,
                        'followers' => $followers,
                        'following' => $following,
                        'posts' => $posts
                    )
                );
                http_response_code(200);
            } else {
                throw new Exception("Failed to update user details");
            }
        } else {
            // If user doesn't exist, insert the user into the database
            $insertSql = "INSERT INTO users (username, profile_image, followers, following, posts) VALUES (?, ?, ?, ?, ?)";
            $insertStmt = $conn->prepare($insertSql);
            $insertStmt->bind_param("ssiii", $username, $profile_image, $followers, $following, $posts);
            $insertStmt->execute();

            if ($insertStmt->affected_rows > 0) {
                $response = array(
                    'status' => true,
                    'message' => 'User details created successfully',
                    'data' => array(
                        'username' => $username,
                        'profile_image' => $profile_image,
                        'followers' => $followers,
                        'following' => $following,
                        'posts' => $posts
                    )
                );
                http_response_code(201); // Created
            } else {
                throw new Exception("Failed to insert user details");
            }
        }

        // Close the prepared statements and connection
        $stmt->close();
        $conn->close();

        echo json_encode($response);
    } catch (Exception $e) {
        // Handle errors
        $response = array(
            'status' => false,
            'message' => 'Error: ' . $e->getMessage(),
            'data' => []
        );
        http_response_code(400); // Bad Request
        echo json_encode($response);
    }
} else {
    // If method is not POST
    $response = array(
        'status' => false,
        'message' => $RequestMethod . ' Method Not Allowed',
        'data' => []
    );
    http_response_code(405); // Method Not Allowed
    echo json_encode($response);
}
?>
